from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import os

with open('wm.png', 'rb') as f:
    data = f.read()

key = os.urandom(16)
iv = os.urandom(16)

cipher = AES.new(key, AES.MODE_CBC, iv=iv)
encrypted_data = cipher.encrypt(pad(data, AES.block_size))

with open('enc.png', 'wb') as f:
    f.write(encrypted_data)



print(''.join(['%02x' % b for b in key]))
# 5073f9ad5703c51f9d13543cfa4b2e90
